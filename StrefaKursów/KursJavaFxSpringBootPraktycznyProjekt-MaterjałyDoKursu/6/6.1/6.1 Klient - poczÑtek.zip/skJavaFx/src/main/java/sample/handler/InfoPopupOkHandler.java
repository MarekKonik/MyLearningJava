package sample.handler;

@FunctionalInterface
public interface InfoPopupOkHandler {

    void handle();
}
