package sample.dto;

import lombok.Data;

@Data
public class OperatorCredentialsDto {

    private String login;
    private String password;

}
