package sample.handler;

public interface InfoPopupOkHandler {

    void handle();
}
