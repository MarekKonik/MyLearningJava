package sample.handler;

@FunctionalInterface
public interface ProcessFinishedHandler {

    void handle();
}
