package pl.strefakursow.skBackend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pl.strefakursow.skBackend.entity.Operator;

public interface OperatorRepository extends JpaRepository<Operator, Long> {
}
