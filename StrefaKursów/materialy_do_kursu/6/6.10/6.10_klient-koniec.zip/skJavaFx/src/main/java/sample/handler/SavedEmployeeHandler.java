package sample.handler;

@FunctionalInterface
public interface SavedEmployeeHandler {

    void handle();
}
