package pl.strefakursow.skBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
