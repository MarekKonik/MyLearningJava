package sample.handler;

public interface DeletedEmployeeHandler {

    void handle();
}
