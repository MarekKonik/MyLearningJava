package sample.handler;

@FunctionalInterface
public interface EmployeeLoadedHandler {

    void handle();
}
